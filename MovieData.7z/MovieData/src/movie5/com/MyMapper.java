package movie5.com;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException 
	{
		String s = value.toString();
		String []s1=s.split(",");
		String year = s1[2].toString().trim();
			try {
				context.write(new Text(year),new IntWritable(1));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}

