package movie2.com;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	int num=0; 
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
    throws IOException, InterruptedException {
  for (IntWritable value : values) { 
	  num += value.get();
	  //context.write(key, new IntWritable(num));
  }
  IntWritable wordCount=new IntWritable(num);
  context.write(new Text("Ans:"), wordCount);
}
}