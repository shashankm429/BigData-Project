package movie2.com;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	double rating;
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException 
	{
		String s = value.toString();
		String []s1=s.split(",");
		if(!s1[3].trim().equals("")){
		rating=Double.parseDouble(s1[3].trim());
		if(rating>4.0){
			try {
				context.write(new Text(),new IntWritable(1));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	}
}
